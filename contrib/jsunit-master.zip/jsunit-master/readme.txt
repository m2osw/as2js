JsUnit

Copyright (c) 2012 Pivotal Labs.
This software is licensed under the MIT License.

JsUnit is no longer maintained by Pivotal Labs or its original author. Pivotal Labs recommends Jasmine (http://pivotal.github.com/jasmine/) for Javascript testing.