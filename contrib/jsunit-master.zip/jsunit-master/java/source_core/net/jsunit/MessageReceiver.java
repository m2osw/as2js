/**
 * 
 */
package net.jsunit;

public interface MessageReceiver {
    public void messageReceived(String message);
}