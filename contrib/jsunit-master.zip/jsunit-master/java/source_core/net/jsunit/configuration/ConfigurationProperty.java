package net.jsunit.configuration;

public interface ConfigurationProperty {
    String getName();
}
