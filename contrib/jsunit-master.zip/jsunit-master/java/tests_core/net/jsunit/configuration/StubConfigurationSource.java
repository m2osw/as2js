package net.jsunit.configuration;

public class StubConfigurationSource implements ConfigurationSource {

    public String browserFileNames() {
        return null;
    }

    public String closeBrowsersAfterTestRuns() {
        return null;
    }

    public String description() {
        return null;
    }

    public String logsDirectory() {
        return null;
    }

    public String logStatus() {
        return null;
    }

    public String port() {
        return null;
    }

    public String remoteMachineURLs() {
        return null;
    }

    public String resourceBase() {
        return null;
    }

    public String timeoutSeconds() {
        return null;
    }

    public String url() {
        return null;
    }

    public String ignoreUnresponsiveRemoteMachines() {
        return null;
    }

    public String osString() {
        return null;
    }

    public String ipAddress() {
        return null;
    }

    public String hostname() {
        return null;
    }

    public String secretKey() {
        return null;
    }

    public String skinsDirectory() {
        return null;
    }

    public String uploadDirectory() {
        return null;
    }

    public String useHTTPS() {
        return null;
    }

}
