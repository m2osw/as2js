package net.jsunit.action;

import net.jsunit.RemoteServerHitter;

public interface RemoteRunnerHitterAware {

    public void setRemoteServerHitter(RemoteServerHitter hitter);

}
