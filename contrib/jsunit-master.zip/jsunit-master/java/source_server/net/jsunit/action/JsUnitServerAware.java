package net.jsunit.action;

import net.jsunit.JsUnitServer;

public interface JsUnitServerAware {
    void setJsUnitServer(JsUnitServer server);

}
