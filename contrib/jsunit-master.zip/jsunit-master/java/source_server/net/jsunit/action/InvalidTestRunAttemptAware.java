package net.jsunit.action;

public interface InvalidTestRunAttemptAware {

    public void setErrorMessage(String errorMessage);

}
