package net.jsunit.action;

import net.jsunit.XmlRenderable;

public interface XmlProducer {

    public XmlRenderable getXmlRenderable();

}
