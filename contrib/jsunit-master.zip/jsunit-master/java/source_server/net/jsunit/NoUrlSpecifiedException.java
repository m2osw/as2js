package net.jsunit;

public class NoUrlSpecifiedException extends Exception {
}
